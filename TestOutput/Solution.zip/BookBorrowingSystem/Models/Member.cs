using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace LibraryApplication.Models;

public class Member
{
    public int Id { get; set; }
    
    [Required]
    public string FirstName { get; set; }
    
    public string LastName { get; set; }
    
    [DisplayName("Е-Адреса")]
    public string Email { get; set; }
    
    // [RegularExpression(pattern: @"\d{9}")]
    public string PhoneNumber { get; set; }
    
    public DateTime MembershipDate { get; set; }
    
    public ICollection<BookBorrowing> Borrowings { get; set; } = new List<BookBorrowing>();
}
