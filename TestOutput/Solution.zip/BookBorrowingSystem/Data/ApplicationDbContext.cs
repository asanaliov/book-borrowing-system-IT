﻿using LibraryApplication.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace BookBorrowingSystem.Data;

public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : IdentityDbContext(options)
{
    public DbSet<Book> Books { get; set; }
    public DbSet<BookBorrowing> BookBorrowings { get; set; }
    public DbSet<Library> Libraries { get; set; }
    public DbSet<LibraryApplicationUser> LibrariesApplicationUsers { get; set; }
    public DbSet<Member> Members { get; set; }
}